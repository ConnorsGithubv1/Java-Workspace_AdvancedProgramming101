package practice;

public class triangleRunner {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		triangle t = new triangle();
		t.getvalues();
		System.out.println(t.getperimeter());
		System.out.println(" ");
		System.out.println("Area == " + t.findarea());
	}

}
